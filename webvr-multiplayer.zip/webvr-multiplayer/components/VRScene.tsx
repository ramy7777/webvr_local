import React, { useEffect, useRef } from 'react';
import { v4 as uuidv4 } from 'uuid';
import Peer from 'peerjs';
import io from 'socket.io-client';

const VRScene: React.FC = () => {
  const sceneRef = useRef<any>(null);
  const peerRef = useRef<Peer | null>(null);
  const connectionsRef = useRef<Map<string, any>>(new Map());
  const playersRef = useRef<Map<string, any>>(new Map());

  useEffect(() => {
    const socket = io('https://your-signaling-server.vercel.app');
    peerRef.current = new Peer(uuidv4());

    peerRef.current.on('open', (id) => {
      console.log('My peer ID is: ' + id);
      socket.emit('join', id);
    });

    socket.on('peers', (peers: string[]) => {
      peers.forEach((peerId) => {
        if (peerId !== peerRef.current?.id && !connectionsRef.current.has(peerId)) {
          const conn = peerRef.current?.connect(peerId);
          if (conn) handleConnection(conn);
        }
      });
    });

    peerRef.current.on('connection', handleConnection);

    return () => {
      socket.disconnect();
      peerRef.current?.destroy();
    };
  }, []);

  const handleConnection = (conn: any) => {
    connectionsRef.current.set(conn.peer, conn);

    conn.on('data', (data: any) => {
      if (data.type === 'position') {
        updatePlayerPosition(conn.peer, data.position);
      }
    });

    conn.on('open', () => {
      addPlayer(conn.peer);
    });

    conn.on('close', () => {
      removePlayer(conn.peer);
      connectionsRef.current.delete(conn.peer);
    });
  };

  const addPlayer = (playerId: string) => {
    if (sceneRef.current && !playersRef.current.has(playerId)) {
      const newPlayer = document.createElement('a-entity');
      newPlayer.setAttribute('id', playerId);
      newPlayer.setAttribute('gltf-model', '#avatar');
      newPlayer.setAttribute('position', { x: 0, y: 1.6, z: 0 });
      newPlayer.setAttribute('scale', { x: 0.5, y: 0.5, z: 0.5 });
      sceneRef.current.appendChild(newPlayer);
      playersRef.current.set(playerId, newPlayer);
    }
  };

  const removePlayer = (playerId: string) => {
    const playerToRemove = playersRef.current.get(playerId);
    if (playerToRemove && sceneRef.current) {
      sceneRef.current.removeChild(playerToRemove);
      playersRef.current.delete(playerId);
    }
  };

  const updatePlayerPosition = (playerId: string, position: any) => {
    const playerEntity = playersRef.current.get(playerId);
    if (playerEntity) {
      playerEntity.setAttribute('position', position);
    }
  };

  useEffect(() => {
    const broadcastPosition = () => {
      const camera = document.querySelector('[camera]');
      if (camera) {
        const position = camera.getAttribute('position');
        connectionsRef.current.forEach((conn) => {
          conn.send({
            type: 'position',
            position: position,
          });
        });
      }
    };

    const interval = setInterval(broadcastPosition, 100);
    return () => clearInterval(interval);
  }, []);

  return (
    <a-scene ref={sceneRef}>
      <a-assets>
        <a-asset-item id="avatar" src="https://cdn.glitch.global/3a0c5d4f-d0e6-4f9c-b1d3-d2d1c0e7f0e9/avatar.glb?v=1698183826479"></a-asset-item>
      </a-assets>

      <a-entity id="rig">
        <a-entity camera look-controls wasd-controls position="0 1.6 0">
          <a-entity cursor="fuse: true; fuseTimeout: 500"
                    position="0 0 -1"
                    geometry="primitive: ring; radiusInner: 0.02; radiusOuter: 0.03"
                    material="color: black; shader: flat">
          </a-entity>
        </a-entity>
      </a-entity>

      <a-sky color="#ECECEC"></a-sky>
      <a-plane position="0 0 0" rotation="-90 0 0" width="100" height="100" color="#7BC8A4"></a-plane>
    </a-scene>
  );
};

export default VRScene;

