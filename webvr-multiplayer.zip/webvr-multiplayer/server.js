import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const server = createServer(app);
const io = new Server(server);

app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

const players = new Map();

io.on('connection', (socket) => {
  console.log('A user connected');

  const playerId = socket.id;
  players.set(playerId, { id: playerId, position: { x: 0, y: 1.6, z: 0 } });

  socket.emit('players', Array.from(players.values()));

  socket.broadcast.emit('playerJoined', players.get(playerId));

  socket.on('updatePosition', (position) => {
    const player = players.get(playerId);
    if (player) {
      player.position = position;
      socket.broadcast.emit('playerMoved', { id: playerId, position });
    }
  });

  socket.on('disconnect', () => {
    console.log('User disconnected');
    players.delete(playerId);
    io.emit('playerLeft', playerId);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

