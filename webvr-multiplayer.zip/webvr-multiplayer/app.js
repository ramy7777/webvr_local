const peer = new Peer(uuid.v4());
const connections = new Map();
const players = new Map();

const scene = document.querySelector('a-scene');
const playerEntity = document.querySelector('#player');

peer.on('open', (id) => {
  console.log('My peer ID is: ' + id);
  joinRoom();
});

peer.on('connection', (conn) => {
  handleConnection(conn);
});

function joinRoom() {
  // In a real application, you'd use a signaling server to exchange peer IDs
  // For this example, we'll use a hardcoded peer ID for demonstration
  const hostPeerId = 'host-peer-id';
  if (peer.id !== hostPeerId) {
    const conn = peer.connect(hostPeerId);
    handleConnection(conn);
  }
}

function handleConnection(conn) {
  connections.set(conn.peer, conn);

  conn.on('data', (data) => {
    if (data.type === 'position') {
      updatePlayerPosition(conn.peer, data.position);
    } else if (data.type === 'players') {
      data.players.forEach((player) => {
        if (player.id !== peer.id && !players.has(player.id)) {
          addPlayer(player);
        }
      });
    }
  });

  conn.on('open', () => {
    conn.send({
      type: 'players',
      players: Array.from(players.values())
    });
  });

  conn.on('close', () => {
    removePlayer(conn.peer);
    connections.delete(conn.peer);
  });

  addPlayer({ id: conn.peer, position: { x: 0, y: 1.6, z: 0 } });
}

function addPlayer(player) {
  const newPlayer = document.createElement('a-entity');
  newPlayer.setAttribute('id', player.id);
  newPlayer.setAttribute('gltf-model', '#avatar');
  newPlayer.setAttribute('position', player.position);
  newPlayer.setAttribute('scale', '0.5 0.5 0.5');
  scene.appendChild(newPlayer);
  players.set(player.id, newPlayer);
}

function removePlayer(playerId) {
  const playerToRemove = players.get(playerId);
  if (playerToRemove) {
    scene.removeChild(playerToRemove);
    players.delete(playerId);
  }
}

function updatePlayerPosition(playerId, position) {
  const playerEntity = players.get(playerId);
  if (playerEntity) {
    playerEntity.setAttribute('position', position);
  }
}

function broadcastPosition() {
  const position = playerEntity.getAttribute('position');
  connections.forEach((conn) => {
    conn.send({
      type: 'position',
      position: position
    });
  });
}

// Update position every 100ms
setInterval(broadcastPosition, 100);

