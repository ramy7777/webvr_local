const socket = io();

const scene = document.querySelector('a-scene');
const playerEntity = document.querySelector('#player');

const otherPlayers = new Map();

socket.on('connect', () => {
  console.log('Connected to server');
});

socket.on('players', (players) => {
  players.forEach((player) => {
    if (player.id !== socket.id) {
      addPlayer(player);
    }
  });
});

socket.on('playerJoined', (player) => {
  addPlayer(player);
});

socket.on('playerMoved', (data) => {
  const playerEntity = otherPlayers.get(data.id);
  if (playerEntity) {
    playerEntity.setAttribute('position', data.position);
  }
});

socket.on('playerLeft', (playerId) => {
  removePlayer(playerId);
});

function addPlayer(player) {
  const newPlayer = document.createElement('a-entity');
  newPlayer.setAttribute('gltf-model', '#avatar');
  newPlayer.setAttribute('position', player.position);
  newPlayer.setAttribute('scale', '0.5 0.5 0.5');
  scene.appendChild(newPlayer);
  otherPlayers.set(player.id, newPlayer);
}

function removePlayer(playerId) {
  const playerToRemove = otherPlayers.get(playerId);
  if (playerToRemove) {
    scene.removeChild(playerToRemove);
    otherPlayers.delete(playerId);
  }
}

function updatePosition() {
  const position = playerEntity.getAttribute('position');
  socket.emit('updatePosition', position);
}

// Update position every 100ms
setInterval(updatePosition, 100);

